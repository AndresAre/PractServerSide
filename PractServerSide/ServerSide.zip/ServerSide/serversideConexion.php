<?php
define("HOST_SS","localhost");
define("DATABASE_SS","usuarios_db");
define("USER_SS","root");
define("PASSWORD_SS","");
?>